# ENGF0034 Tetris autoplayer

The ordinary player achieved **52,196 median** on ten paired seeds using Python 3.7.9. The resource-free predictive settings now selected achieved **66,415.5 median** on the same ten seeds, with a best score of **69,855**. These are local measurements; the earlier resource-enabled comparison and its results are preserved below.

Ordinary play uses the current piece and preview, with ten discards and five bombs available. Deeper search requires a matching seed in the player's own environment. Predictive play uses normal placements only, keeping its sequence and search state simpler.

The previous predictive version achieved **61,919.5 median across 20 previously unseen games on Python 3.7.9**. Its frozen sources are preserved in `baselines/v1` for paired comparisons. Whether the actual grader exposes SEED remains unverified; ordinary play does not depend on it.

## Improvement priorities

1. Fast, checked simulation and beam search, allowing several promising plans to survive deeper into the search.
2. Better long-term board shape: few holes, a smooth building area outside the scoring well, and room to prepare consecutive four-row clears.
3. Optional future-piece prediction, enabled only after matching six observed pieces.
4. Selective discards and bombs in ordinary play, accounting for the pieces and cells sacrificed.
5. Parameter experiments on development seeds followed by frozen evaluation on unseen seeds.

The first priorities produced the largest gains. A larger shortlist alone had previously regressed on the default seed, so it was not adopted as a general solution.

## Run locally

The launchers use this folder's .venv and work from any current directory.

| Mode | Command |
| --- | --- |
| Play manually in Pygame | .\scripts\play.cmd |
| Watch with the normal environment | .\scripts\watch.cmd |
| Watch with a matching local seed | .\scripts\watch-predict.cmd |
| Watch another local integer seed | .\scripts\watch-predict.cmd -Seed 17 |
| Watch with a rolling predictive search | .\scripts\watch-predict.cmd -LiveSearch |
| Tkinter manual / auto | .\scripts\play-tk.cmd / .\scripts\watch-tk.cmd |
| Terminal manual / auto | .\scripts\play-terminal.cmd / .\scripts\watch-terminal.cmd |

The predicted launcher sets the local generator and predictor to matching seed values. It does not alter the game rules. The ordinary launcher uses visible-piece search when its environment has no matching SEED. Piece sequences are repeatable; CPU budgets can change completed search depth and decisions on different hardware or under different loads.

Arrows move or rotate, Space drops, z rotates anticlockwise, d discards, b prepares a bomb, and Esc exits.

## How to read player.py

All bot logic is in [player.py](player.py). The game starts with `SelectedPlayer = SearchPlayer` at the bottom. Read `SearchPlayer.choose_action` first, then follow its calls into the predictor and planner. Reading from the first line encounters the older fallback before reaching the main algorithm.

| Class | Purpose |
| --- | --- |
| `Player` | Defines the `choose_action` interface expected by the engine |
| `RandomPlayer` | Keeps the supplied random example available for comparisons |
| `HeuristicPlayer` | Plays prediction warm-up and handles search failures |
| `SeedPredictor` | Reconstructs and checks the sequence from the supplied seed |
| `Landing` | Records one completed piece's board, points, actions and resource use |
| `SearchNode` | Records a partially explored sequence, its ranking and parent link |
| `Planner` | Simulates placements, evaluates boards and searches possible futures |
| `SearchPlayer` | Selects the mode, verifies moves and manages the saved plan |

The earlier readability cleanup shortened fallback comparisons and evaluation, removed repeated guards and an unused attribute, and separated finding a landing from recording it. A cached landing is verified once. Comments remain lowercase with light punctuation; there are no lambdas or method decorators.

That cleanup preserved the planner's syntax tree apart from comments and matched 1,120 fallback evaluations, 72 fallback decisions, 120 predictor observations and two full game traces. Its [verification details](reports/readability-refactor.json) describe that historical change. The subsequent predictive resource removal deliberately changes predictive choices to the previously tested resource-free model; ordinary resource logic remains available.

The resource removal shortened player.py from 1,153 to 1,109 lines. All 39 tests pass on Python 3.7.9. Full-game checks matched all 399 decisions in each mode: basic seed 42 remained 56,947 with six discards and one bomb, while the predictive regression matched the previous resource-disabled player at 69,855 with no resources used. The evaluator, ordinary chance search, immediate resource generation and move verification are unchanged. [Verification details](reports/predictive-resource-removal.json) include hashes, results and local timings.

## Algorithm walkthrough

### 1. Receive a board and choose a mode

The engine calls `SearchPlayer.choose_action(board)` with a copy of the current game. The bot returns an action list ending the current piece, so normally one call means one placed or discarded piece. It increments `turn`, reads the current shape and preview, and checks the predictor.

The generator allows 400 draws but replenishes the preview before asking for another move. This leaves 399 playable pieces. Remaining-piece calculations consistently reserve the final preview, including after discards.

There are three usual paths. A missing or mismatching seed uses ordinary visible-piece search. A supplied seed that is still being checked uses `HeuristicPlayer`. A verified seed enables predictive search. Unexpected search errors also use `HeuristicPlayer` so the game can continue.

### 2. Verify the seed before using future pieces

`SeedPredictor.__init__` reproduces the generator with Python's `Random`. The actual generator independently chooses one of seven normal shapes on every draw; it does not deal a seven-piece bag. The predictor tries the seed's supplied form and, where applicable, its integer interpretation because the referee and local interface can seed differently.

`observe` removes any candidate sequence whose current piece or preview disagrees with reality. Prediction starts only when one candidate remains and six distinct random piece positions have matched. The first call observes positions zero and one; after four placements the fifth current piece and its preview supply the sixth observation. This explains the four-piece warm-up.

`future` returns the appropriate slice of the surviving sequence, excluding the unplayable final preview. Every later call checks the current piece and preview again. Verification establishes that the sequence matches; it does not establish permission to use seed-based prediction under assignment rules.

### 3. Represent settled cells with column bits

`columns_from_board` converts the occupied cells into ten integers, one per column. Bit `y` is set if that column contains a cell at row `y`. The tuple of integers is immutable and can be a dictionary key when removing duplicate search states.

For example, on a six-row board, cells at rows 2, 3 and 5 give a column value of `4 + 8 + 32 = 44`, or binary `101100`. Its height is four rows, it contains three filled cells, and therefore it has one buried hole at row 4.

`measure` gets the first occupied row from the lowest set bit, counts the filled bits and calculates holes as height minus filled-cell count. `collides` checks a proposed piece against column bits and board boundaries. These operations avoid repeatedly constructing full engine boards during the large search.

### 4. Generate possible landings

`make_templates` uses an empty engine board to prepare the four rotation sequences: none, clockwise, twice clockwise and anticlockwise. Each template records the resulting cells, steering dimensions, descent points and intermediate cells that need collision checks. The single-cell bomb needs no rotation variants and remains supported for ordinary play.

`placements` tries each allowed template at every horizontal target. It simulates sideways moves together with their compulsory gravity steps. If gravity lands the piece before its target is reached, the plan ends there. Otherwise bit operations determine the hard-drop distance. That distance earns the same descent points as moving through those rows normally.

The simulation merges a normal piece's cells into the columns. A bomb instead calls `explode`, removing its three-by-three neighbourhood and compacting cells above the blast in the affected columns. `clear_rows` removes completed rows, shifts the rows above them down, and adds the real simultaneous-clear reward. Outcomes requiring more than four simultaneous clears are skipped because the supplied engine cannot score them.

Equivalent landing outcomes are deduplicated in their existing generation order. The generator deliberately covers rotation, steering and dropping plans; it is not an exhaustive search of every possible tuck or late rotation.

### 5. Evaluate a board's future usefulness

`Planner.evaluate` combines real points already earned with estimated future value. Real points are divided by 25 so a single, double, triple and four-row clear contribute 1, 4, 16 and 64 respectively.

| Feature | Default weight | Meaning |
| --- | ---: | --- |
| Total height | 0.20 | Penalise filling the available headroom |
| Buried holes | 12.0 | Penalise empty cells covered by occupied cells |
| Surface bumpiness | 0.60 | Prefer a building surface with small height differences |
| Danger | 1.0 | Penalise the square of the height above ten rows |
| Prepared scoring rows | 1.0 | Reward opportunities for future four-row clears |
| Occupied well cells | 0.0 | An available optional penalty, disabled by default |

The planner identifies a potential left or right edge well and leaves its intended depth out of the bumpiness penalty. If that well is empty, it counts consecutive bottom rows filled everywhere else. Four ready rows have an estimated value of 64; partial groups use values 6, 14 and 30. This makes completing a four-row setup attractive compared with cashing it as smaller clears. Ordinary play recognises up to eight prepared rows; predictive play recognises twelve.

The rough formula is real points divided by 25, plus setup value, minus height, holes, bumpiness, danger and resource opportunity costs. The actual arithmetic order remains explicit in the code because rearranging floating-point operations can change close comparisons.

### 6. Search without a verified seed

`chance_search` knows the current piece and preview. It first tries current-piece landings and their preview responses, ranks those outcomes, and shortlists six current-piece candidates. It retains four promising preview responses per candidate, with room to preserve an additional discard response.

For each shortlisted current placement, it considers all seven possible third shapes. Each shape gets the best available preview response and third-piece placement; those seven best results are averaged. This information order matters: the third shape is unknown when choosing the current placement, but will be visible before placing today's preview. The bot can therefore plan a different preview response for each possible third shape.

It returns the current placement with the best expected result, using the existing immediate-value tie-break. A 0.5-CPU-second budget limits ordinary search. Near the end it uses only the pieces that can actually be played. If every preview would top out, it takes the most immediate real points available from the current piece.

### 7. Search a verified future with a beam

`search` starts with one `SearchNode` for the current board. Each layer advances every surviving node by one piece. Predictive play offers normal placements only. Nodes store columns, cumulative points, ranking, the first landing and optional parent links. The shared node also carries discard counts and costs for ordinary search; these remain zero in predictive play. There is no future bomb budget or forced-preview state in a node.

Predictive states with identical columns share a dictionary key at the same depth. The existing ranking decides which history to retain for each key. Ordinary search also distinguishes discard counts and an immediate bomb preview when relevant. Candidates are ordered by evaluated value, then the value of the first landing, then cumulative real points. Stable ordering preserves earlier generation order for remaining ties.

The best 256 nodes survive in whole-game mode. This beam prevents the number of possibilities multiplying without bound, while retaining alternatives to the immediately best-looking placement. It is an approximation, not a proof of the optimal game.

### 8. Recover and reuse the whole-game plan

Whole-game search explores the remaining sequence, normally 395 pieces after warm-up. `SearchNode.parent` points to the preceding node and `step` stores the landing that produced the child. At the best completed layer, the planner follows those links backwards and reverses the collected landings into chronological order.

`find_landing` returns the first landing and stores the rest in `saved_plan`. Later calls take the next cached landing, so those futures are not recalculated. This causes the initial planning pause, followed by relatively fast playback. This cleanup preserves that behaviour.

The alternative local `-LiveSearch` mode searches a rolling 16-piece window with a 24-board beam. It also uses normal placements only. Defaults remain embedded in player.py; JSON profiles are used only when explicitly supplied to benchmark tools.

### 9. Use bombs and discards in ordinary play

In ordinary play, `options` offers a discard when a resource and another playable piece remain. It removes the current piece permanently, promotes the preview and advances the sequence once. Each branch tracks how many discards it has left. `allow_discards` and `allow_bombs` configure this ordinary mode; predictive play ignores both flags.

A bomb changes the preview into a bomb while gravity still acts on the current piece. Bomb preparation is considered when the stack reaches fourteen rows or contains at least three holes. `resource_landings` checks the actual remaining bomb budget and uses engine clones to model preparing one now. Ordinary search then evaluates the resulting bomb preview. Future bomb preparation templates have been removed.

The ordinary costs are 6.4 evaluation units for a discarded or replaced tetromino and 1.6 per cell destroyed by a blast. These correspond to 160 and 40 estimated points: a perfect four-row clear earns 1,600 points from forty cells. These costs are estimates used for ranking, not deductions from the actual score. Using every resource is therefore not a goal.

Predictive play cannot replace or discard a piece, so its random sequence remains unchanged. `SeedPredictor` no longer needs replacement tracking or special counting for bomb observations. During seed checking the original fallback uses normal placements; once a mismatch occurs, prediction stays disabled and ordinary play can use resources safely.

### 10. Cash in setups before the piece budget ends

Prepared-row value decreases during the last seven remaining pieces. Resource opportunity costs decrease during the last eight. At zero remaining pieces, `evaluate` returns only real points divided by 25 and the resource cost factor becomes zero. An unfinished setup or an attractive board shape has no remaining value then.

This is why the finite piece budget matters throughout planning. Surviving forever is not the objective; the retained final board is the one preferred by the completed search using actual final points.

### 11. Verify each action list against the real engine

`verify_plan` replays the candidate's actions on a clone of the supplied board. It requires the current piece to land on the final action, compares the points and resource consumption, checks a forced bomb preview, and compares every occupied cell with the fast simulation's prediction.

A cached landing is checked once before use. A newly searched landing is also checked before it is returned. If a cached plan no longer matches, it is discarded and a new search is attempted. If search or verification fails, `fallback` uses `HeuristicPlayer`.

The fallback enumerates landings on real engine clones, ranks them, and examines the preview for its best four current-piece candidates. Its older evaluator includes buried-hole depth and a four-row setup bonus. It remains separate to preserve the opening moves and emergency behaviour that were already tested.

### 12. Respect the computation budget

The large search has a 260-CPU-second limit per planning call and a cumulative 300-CPU-second planning budget. If a call finishes only part of the sequence, the valid prefix can be played and the remaining position searched later. Once the cumulative budget is exhausted, subsequent searches use the smaller rolling beam with a 0.15-second budget. Deadline checks happen after completed search layers, so the last layer can slightly exceed a nominal cutoff.

The normal player uses one process, standard-library modules and the supplied engine files. It performs no disk writes or network calls. Counters such as search depth, cached decisions and verification failures are diagnostics for local benchmarks; they do not add game points. The application's animation and the server's total wall-time limit are separate from the search's CPU-time accounting.

## Scoring and constraints

- Deadline: Wednesday 25 November 2026, 23:59 UK time.
- The grading result is the median score across multiple secret piece sequences.
- Passing requires beating RandomPlayer; full marks require the highest cohort median.
- Clearing 1, 2, 3 or 4 rows together earns 25, 100, 400 or 1,600 points.
- Descending a piece earns one point per row.
- The generator supplies 400 pieces, including previews; discards consume that supply.
- Ten discards and five bombs are available.
- The stated grader runtime is Python 3.7.9, standard library only.
- The slides specify 256 MB RAM, 50% of one CPU core and 15 minutes.
- Crashes or memory exhaustion invalidate a run; reaching time or piece limits keeps the score.
- The grader maintains its own game state.

References: [brief](docs/assignment4.pdf), [introductory slides](docs/tetris.pdf), [follow-up slides](docs/tetris-follow-up.pdf).

## Previous predictive baseline

Development progressed from about 49k to 58k and then 63k medians. The important change was recognising additional clean four-row preparations while retaining a usable board shape. The selected adaptive-well configuration scored 62,493, 63,306 and 63,823 on the initial development games. A separate development game on actual Python 3.7.9 scored 65,432.

The parameters were then frozen. Twenty new random string seeds were generated for validation. All outcomes count, including early losses and failures. The validation report records source hashes, interpreter version, parameters, scores, line clears, stack heights, holes, CPU times, prediction matches and fallback use. No parameter changes are made against this batch.

Validation status: **passed**.

| Measurement | Result |
| --- | ---: |
| Games | 20 |
| Median score | 61,919.5 |
| Minimum / maximum | 2,986 / 68,604 |
| Reached the piece limit | 19 / 20 |
| Prediction mismatches / plan-verification failures | 0 / 0 |
| Maximum local CPU / wall time | 137.5 s / 138.4 s |
| Observed local worker peak memory | About 21 MB |

An order-statistic interval for the population median is 60,732–63,389, with approximately 95.9% coverage under independent sampling. This provides evidence of generalisation, not a guarantee against every future failure or every form of overfitting. This baseline did not use bombs or discards and had one early top-out.

Full [results](reports/validation-a.json), [seed manifest](reports/validation-a-seeds.json), [frozen protocol](reports/validation-protocol.json) and [audit](reports/validation-audit.json) are saved in reports. These are local measurements, not new official grader scores. Actual grading hardware and whether it exposes SEED still require a live grading check.

The default integer seed 42 scored 40,647 in fallback mode and 63,670 with a matching local seed. Both runs reached the piece limit. Their records are [fallback](reports/seed42-fallback.json) and [prediction-enabled](reports/seed42-predicted.json).

Source files and the seed manifest are checked against the frozen protocol before accepting the result. This controls overfitting through separation of development and validation; it cannot guarantee performance on every future sequence.

To run development comparisons:

    .\.venv\Scripts\python.exe scripts/experiment.py --profiles configs/development.json --seeds development-0 development-1 development-2 --output .setup/my-development.json

To evaluate the selected configuration:

    .\.venv\Scripts\python.exe scripts/experiment.py --profiles configs/predicted.json --seed-file reports/validation-a-seeds.json --workers 4 --output .setup/my-validation.json

To audit that historical validation against its archived runtime sources:

    .\.setup\python37\python.exe scripts/audit_validation.py --report reports/validation-a.json --protocol reports/validation-protocol.json --seeds reports/validation-a-seeds.json --source-root baselines/v1 --output .setup/rechecked-audit.json

Use fresh validation seeds after further tuning. Repeatedly choosing changes against the same validation set turns it into development data. The older scripts/tune.py compares coefficients for the basic fallback; enhanced-search profiles belong in configs and are measured with scripts/experiment.py.

## Basic search and resource development

Four development seeds were used for the basic-player comparison. All runs used the actual game rules and 400 generated pieces, including the final unplayable preview. These development results selected the configuration; they are not an independent validation claim.

| Configuration | Median | Minimum | Reached piece limit |
| --- | ---: | ---: | ---: |
| Previous basic player | 12,758 | 2,866 | 0/4 |
| Chance search with resource costs | 49,326.5 | 43,520 | 2/4 |
| Lower setup reward, higher safety and discard cost | 45,808.5 | 20,167 | 2/4 |
| Cheaper discards | 38,585 | 21,289 | 2/4 |
| Wider chance search | 41,612 | 21,201 | 2/4 |

The standard six-candidate configuration won this comparison. The default integer seed 42 also improved from 40,647 to 56,947 on both Python 3.7.9 and the local Python 3.11 used by watch.cmd, using six discards and one bomb. This is a regression check, not a reason to tune against that seed. The current local check is saved in [seed42-basic-current.json](reports/seed42-basic-current.json).

The ordinary configuration is in [configs/basic.json](configs/basic.json). Run it with:

    .\.setup\python37\python.exe scripts/experiment.py --profiles configs/basic.json --seeds my-development-0 my-development-1 --output .setup/basic-development.json

## Current predictive selection

The selected mode plans the remaining playable sequence with a 256-board beam, up to twelve prepared rows and a 260-CPU-second limit per planning call. It now excludes bombs and discards. The earlier resource-enabled version scored 65,349, 63,278 and 61,974 on three development games; all reached the piece limit. It used 197–209 CPU seconds and peaked around 55 MB. The 384-board alternative with eight prepared rows scored 65,868, 62,439 and 61,265, used 261–264 CPU seconds, and was not selected.

These are development results. The selected parameters and runtime hashes were frozen before generating ten new string seeds for the paired validation below.

## Fresh paired validation

Historical validation status: **passed**. These results precede predictive resource removal. Each mode used the same ten new seeds for its old and new player. The experiment ran on Python 3.7.9, with every declared result included. The new ordinary player used no seed prediction; the predictive comparison supplied matching string seeds through the environment. This does not establish whether the actual grader exposes SEED.

| Measurement | Ordinary player | Predictive player |
| --- | ---: | ---: |
| Previous median | 30,957.5 | 61,523 |
| New median | **52,196** | **66,334.5** |
| Median increase | 68.6% | 7.8% |
| Paired wins | 10/10 | 10/10 |
| New minimum / maximum | 36,436 / 59,919 | 63,633 / 69,864 |
| New games reaching piece limit | 7/10 | 10/10 |
| Crashes / failed move checks | 0 / 0 | 0 / 0 |
| Maximum local CPU / wall time | 167.1 s / 169.1 s | 261.0 s / 263.7 s |
| Peak process memory | 23.4 MB | 59.4 MB |
| Bombs / discards used across ten games | 43 / 89 | 5 / 6 |

The audit checks the frozen source hashes, complete seed/profile coverage, interpreter version, score accounting, resource limits, prediction alignment and saved-plan use. The three early ordinary-player losses remain in its median. The results support an improvement on this held-out batch; beam search still does not prove a globally optimal score or guarantee the cohort ranking.

The 69,864-point game made **39 four-row clears**, one double and one single, using one discard. Thirty-nine is the maximum possible number of four-row clears from this piece budget: 399 playable normal pieces provide at most 1,596 cells, while forty four-row clears would need 1,600. Bombs and discards reduce the available cells. Reaching that quad count does not establish the maximum total score; grouping the remaining clears and maximising descent points still matter.

The [frozen protocol](reports/comparison-b-protocol.json), [all forty results](reports/comparison-b-results.json), [seed manifest](reports/comparison-b-protocol-seeds.json) and [audit](reports/comparison-b-audit.json) are saved together. The memory numbers are conservative process-lifetime peaks from benchmark workers, which can include preceding games in the same worker. These are local tests, not new official grader results.

The player and planner were subsequently combined into player.py without changing any of the eight class bodies. The original split sources are archived in baselines/v2 so the historical hashes can still be audited. [player-consolidation.json](reports/player-consolidation.json) records the original hashes, combined-file hash and matching class syntax trees. The archived files are only for historical checks; the active player uses one file.

The following command used the then-current player. Reproducing its historical predictive results requires the original resource-enabled sources:

    .\.setup\python37\python.exe scripts/experiment.py --profiles reports/comparison-b-protocol-profiles.json --seed-file reports/comparison-b-protocol-seeds.json --workers 4 --output .setup/replayed-comparison.json

To audit the saved comparison against its original archived sources:

    .\.setup\python37\python.exe scripts/audit_comparison.py --report reports/comparison-b-results.json --protocol reports/comparison-b-protocol.json --source-root baselines/v2 --output .setup/rechecked-comparison-audit.json

For a new validation after changing parameters, freeze a new protocol and generate new seeds. Keep this batch intact:

    .\.setup\python37\python.exe scripts/freeze_comparison.py --games 10 --output reports/comparison-c-protocol.json
    .\.setup\python37\python.exe scripts/experiment.py --profiles reports/comparison-c-protocol-profiles.json --seed-file reports/comparison-c-protocol-seeds.json --workers 4 --output reports/comparison-c-results.json

## Bomb and discard ablation

With both special actions disabled, the current player was measured on the same ten seeds as the earlier comparison, using Python 3.7.9 and the same weights. All twenty outcomes count, and every run used zero bombs and zero discards.

| Mode | Median with resources | Median without resources | Range without resources | Reached piece limit without resources |
| --- | ---: | ---: | ---: | ---: |
| Basic | 52,196 | 25,956.5 | 6,504–53,099 | 2/10 |
| Predictive | 66,334.5 | 66,415.5 | 65,501–69,855 | 10/10 |

Resources substantially improve the current basic player's survival and median. Predictive performance was similar, with its median 81 points higher without resources on this batch. This small difference is not enough to establish a general improvement. A finite beam can retain different plans when resource branches are present, even though adding legal choices cannot reduce the true optimal score.

This was a direct ablation against the saved enabled results, not a retuning for play without resources. Predictive mode now adopts the resource-free setting; ordinary mode keeps both resources. The [configuration](configs/no-resources.json), [all results](reports/no-resources-results.json) and [checked summary](reports/no-resources-summary.json) are saved for inspection. There were no crashes or move-verification failures.

To repeat the disabled-resource experiment:

    .\.setup\python37\python.exe scripts/experiment.py --profiles configs/no-resources.json --seed-file reports/comparison-b-protocol-seeds.json --workers 4 --output .setup/no-resources-replay.json

### Individual resource switches in predictive mode

The same three settings tested on integer seed 42 were then measured on ten additional matched string seeds, using local Python 3.11.9. All other weights and search parameters remained identical. This was thirty full games and reused the earlier comparison seed batch; it is an exploratory comparison rather than a fresh validation after selecting a winner.

| Setting | Median | Minimum | Maximum | Wins against both enabled |
| --- | ---: | ---: | ---: | ---: |
| Both enabled | 66,334.5 | 64,554 | 69,864 | — |
| No discards, bombs allowed | 66,331.5 | 64,838 | 69,847 | 6/10 |
| No bombs, discards allowed | 66,345 | 64,728 | 69,855 | 8/10 |

All thirty games reached the piece limit, completed the full initial 395-piece predictive search, and had zero move-verification failures or planning cutoffs. The median differences are practically negligible on this batch. Allowing extra actions changes which boards survive the finite beam, so restricted settings can win individual seeds even when the winning plan uses few resources.

Across ten games, both-enabled plans used five bombs and six discards; no-discard plans used eleven bombs; no-bomb plans used three discards. These historical results concern predictive mode; the earlier ordinary-player experiment showed a substantial benefit from resource availability. They motivated removing predictive resource branches while retaining ordinary resources.

[All thirty results](reports/resource-ablation-multiseed.json), the [checked summary with per-seed scores](reports/resource-ablation-multiseed-summary.json) and the [historical profiles](reports/resource-ablation-profiles-historical.json) are saved. Those three profiles require the original resource-enabled implementation to reproduce; with the current player they all use resource-free predictive search.

## CPU, memory and chess-engine search

The board representation and beam search resemble a chess engine's compact state and selective search. Here, random future shapes are chance events; ordinary adversarial alpha-beta search would model the wrong opponent. A verified sequence removes that uncertainty, but exhaustive search remains impractical because placements multiply at every piece.

Python 3.7's GIL permits only one thread to execute Python code at a time, so Python threads do not accelerate this CPU-bound search. Separate processes bypass the GIL, but the grader's aggregate allowance remains half of one core, and processes add communication and memory costs. See the official [threading](https://raw.githubusercontent.com/python/cpython/3.7/Doc/library/threading.rst) and [multiprocessing](https://raw.githubusercontent.com/python/cpython/3.7/Doc/library/multiprocessing.rst) documentation.

The useful approaches are faster single-process simulation, better evaluation, reusing plans, selective search and measured depth/width choices. Local benchmarks use separate processes to run independent games concurrently; the submitted player uses one process. Increasing the predictive rolling search from width 32/depth 8 to width 48/depth 12 used about 256 CPU seconds per development game without improving the median. A whole-game width-128 plan used about 80 CPU seconds on two development games, scoring 64,347 and 61,691 while reusing 394 verified plans in each. More computation can help specific positions, but how it is spent and how boards are evaluated also limits score.

The resource-aware seed-42 check used about 160 CPU seconds and a 21 MB process memory peak. These local measurements leave substantial memory headroom under 256 MB; CPU is the tighter search budget. Wall time on a half-core server can be roughly twice CPU time, with additional scheduling overhead. Local measurements do not reproduce the grading container.

## Tests and setup

    .\.venv\Scripts\python.exe -m unittest discover -s tests -v

All 39 tests pass on Python 3.7.9. They compare over 1,000 simulated landings, including bombs and high stacks, with the supplied engine; check ordinary bomb preparation, discard alignment, resource-free predictive plans in whole-game, rolling and budget-exhausted modes, saved-plan reuse and invalidation, exhausted resources and terminal scoring; and exercise the original two-process referee/player protocol with matching, missing and incorrect seed environments. The portable interpreter used for validation is in .setup/python37.

To recreate local interface dependencies:

    python -m venv .venv
    .\.venv\Scripts\python.exe -m pip install -r requirements-local.txt

Pygame and Windows curses are for local interfaces only. The submitted player and planner require no third-party packages.

## Submission

The enrolled fork is [alistairlee26/tetris](https://scm4.cs.ucl.ac.uk/alistairlee26/tetris). Commit 157dc6f is the earlier submitted player; its official median was 30,867. The new implementation has not been submitted.

All custom player logic is in player.py; submit that file alongside the original supplied game files. Pushing the submission branch triggers grading. The [grading dashboard](https://engf0002.cs.ucl.ac.uk/submissions/tetris) requires GitLab sign-in.

The .setup folder contains local interpreters, historical experiments and working reports. It and .venv are excluded from Git.
