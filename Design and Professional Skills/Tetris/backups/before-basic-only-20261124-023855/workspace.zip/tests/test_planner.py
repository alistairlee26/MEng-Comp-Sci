import unittest
from random import Random
import os
from unittest.mock import patch

from board import Board, Block, Shape, Rotation, Action
from player import Planner, SeedPredictor, SearchPlayer


class PlannerTests(unittest.TestCase):
    def make_board(self, shape, cells):
        board = Board(10, 24)
        board.cells = set(cells)
        board.cellcolor = {}
        for cell in cells:
            board.cellcolor[cell] = 'blue'
        board.next = Block(shape)
        board.place_next_block()
        board.next = Block(Shape.O)
        return board

    def test_fast_landings_match_the_real_engine(self):
        generator = Random(835721)
        patterns = [[], [(x, y) for x in range(1, 10) for y in range(20, 24)]]
        for pattern in range(5):
            cells = []
            for x in range(10):
                height = generator.randrange(9)
                for y in range(24 - height, 24):
                    if generator.random() > 0.10:
                        cells.append((x, y))
            patterns.append(cells)
        # A rescue search also has to model gravity near the spawn correctly.
        for height in (14, 19, 22):
            cells = []
            for x in range(10):
                if x == 0:
                    continue
                for y in range(24 - height, 24):
                    if generator.random() > 0.08:
                        cells.append((x, y))
            patterns.append(cells)

        planner = Planner()
        compared = 0
        for shape in Shape:
            for cells in patterns:
                board = self.make_board(shape, cells)
                columns = planner.columns_from_board(board)
                for landing in planner.placements(columns, shape):
                    sandbox = board.clone()
                    for index, move in enumerate(landing.moves):
                        if isinstance(move, Rotation):
                            landed = sandbox.rotate(move)
                        else:
                            landed = sandbox.move(move)
                        if landed:
                            self.assertEqual(index, len(landing.moves) - 1)
                            break
                    self.assertTrue(landed)
                    self.assertEqual(planner.columns_from_board(sandbox), landing.columns)
                    self.assertEqual(sandbox.score - board.score, landing.points)
                    compared += 1
        self.assertGreater(compared, 1000)

    def test_predictive_modes_never_consider_resources(self):
        for whole_game, exhausted in ((True, False), (False, False), (True, True)):
            with self.subTest(whole_game=whole_game, exhausted=exhausted):
                player = SearchPlayer(seed='normal-piece-plan', block_limit=12,
                                      whole_game=whole_game, whole_game_width=8,
                                      whole_game_time_limit=10, search_time_limit=10,
                                      allow_discards=True, allow_bombs=True)
                sequence = player.predictor.candidates[0].copy()
                for index in range(4):
                    player.predictor.observe(index, sequence[index], sequence[index + 1])
                player.turn = 4
                if exhausted:
                    player.whole_game_cpu = 300
                cells = [(x, y) for x in range(1, 10) for y in range(10, 24)
                         if (x, y) not in ((4, 18), (4, 20), (7, 19))]
                board = self.make_board(sequence[4], cells)
                board.next = Block(sequence[5])
                with patch.object(player, 'resource_landings',
                                  side_effect=AssertionError('predictive resource search')):
                    moves = player.choose_action(board)
                self.assertNotIn(Action.Bomb, moves)
                self.assertNotIn(Action.Discard, moves)
                self.assertEqual(player.predicted_decisions, 1)
                self.assertEqual(player.planning_failures, 0)
                for landing in player.saved_plan:
                    self.assertNotIn(Action.Bomb, landing.moves)
                    self.assertNotIn(Action.Discard, landing.moves)

    def test_whole_game_path_uses_normal_pieces_and_replays_on_the_engine(self):
        planner = Planner(beam_width=32, time_limit=10)
        cells = [(x, y) for x in range(1, 10) for y in range(10, 24)
                 if (x, y) not in ((4, 18), (4, 20), (7, 19))]
        shapes = [Shape.O, Shape.L, Shape.T, Shape.S, Shape.Z, Shape.O]
        board = self.make_board(shapes[0], cells)
        board.next = Block(shapes[1])
        planner.search(board, shapes, len(shapes), remember_path=True)
        self.assertEqual(len(planner.last_path), len(shapes))
        for position, landing in enumerate(planner.last_path):
            starting_score = board.score
            self.assertNotIn(Action.Bomb, landing.moves)
            self.assertNotIn(Action.Discard, landing.moves)
            for index, move in enumerate(landing.moves):
                if isinstance(move, Rotation):
                    landed = board.rotate(move)
                else:
                    landed = board.move(move)
                if landed:
                    self.assertEqual(index, len(landing.moves) - 1)
                    break
            self.assertTrue(landed)
            self.assertEqual(planner.columns_from_board(board), landing.columns)
            self.assertEqual(board.score - starting_score, landing.points)
            if position + 2 < len(shapes):
                board.next = Block(shapes[position + 2])
        self.assertEqual(board.bombs_remaining, 5)
        self.assertEqual(board.discards_remaining, 10)

    def test_basic_bomb_does_not_modify_a_failed_predictor(self):
        player = SearchPlayer(seed='incorrect-seed')
        player.predictor.candidates = []
        player.predictor.status = 'mismatch'
        player.planner = Planner()
        from player import Landing
        landing = Landing((0,) * 10, 0, [Action.Bomb], 0, bombs=1,
                          next_shape=Shape.B)
        player.record_plan(landing, False, False)
        self.assertEqual(player.bomb_decisions, 1)
        self.assertEqual(player.predictor.status, 'mismatch')
        self.assertEqual(player.predictor.future(0, 10), [])

    def test_visible_piece_search_does_not_read_the_seed(self):
        board = self.make_board(Shape.T, [])
        board.next = Block(Shape.L)
        options = {
            'use_prediction': False, 'basic_mode': 'chance',
            'basic_root_width': 2, 'basic_preview_width': 2,
            'search_time_limit': 10,
        }
        with patch.dict(os.environ, {'SEED': 'first-unrelated-seed'}):
            first = SearchPlayer(**options)
            first_moves = first.choose_action(board)
        with patch.dict(os.environ, {'SEED': 'second-unrelated-seed'}):
            second = SearchPlayer(**options)
            second_moves = second.choose_action(board)
        self.assertEqual(first_moves, second_moves)
        self.assertEqual(first.predictor.status, 'missing')
        self.assertEqual(first.predicted_decisions, 0)
        self.assertEqual(first.known_decisions, 1)

    def test_bomb_root_plans_replay_on_the_actual_engine(self):
        from board import Action
        cells = []
        for x in range(1, 10):
            for y in range(10, 24):
                if (x, y) not in ((4, 18), (4, 20), (7, 19)):
                    cells.append((x, y))
        board = self.make_board(Shape.O, cells)
        player = SearchPlayer(use_prediction=False, basic_mode='known', allow_bombs=True)
        player.planner = player.make_planner(board, None)
        choices = player.resource_landings(board, 100)
        bomb_plans = []
        for landing in choices:
            if Action.Bomb in landing.moves:
                bomb_plans.append(landing)
                self.assertTrue(player.verify_plan(board, landing))
                self.assertEqual(landing.next_shape, Shape.B)
        self.assertTrue(bomb_plans)

    def test_an_available_four_row_clear_is_preferred_to_discarding(self):
        from board import Action
        board = self.make_board(Shape.I, [(x, y) for x in range(1, 10)
                                        for y in range(20, 24)])
        player = SearchPlayer(use_prediction=False, basic_mode='known', allow_discards=True)
        moves = player.choose_action(board)
        self.assertNotIn(Action.Discard, moves)
        sandbox = board.clone()
        for move in moves:
            if isinstance(move, Rotation):
                landed = sandbox.rotate(move)
            else:
                landed = sandbox.move(move)
            if landed:
                break
        self.assertGreaterEqual(sandbox.score, 1600)

    def test_terminal_evaluation_only_counts_real_points(self):
        planner = Planner()
        empty = (0,) * 10
        damaged = (0, 1 << 3) + (0,) * 8
        self.assertEqual(planner.evaluate(empty, 400, 0), 16)
        self.assertEqual(planner.evaluate(damaged, 400, 0), 16)

    def test_no_resources_are_invented_after_exhaustion(self):
        from board import Action
        board = self.make_board(Shape.O, [(x, y) for x in range(1, 10)
                                        for y in range(10, 24)])
        board.discards_remaining = 0
        board.bombs_remaining = 0
        player = SearchPlayer(use_prediction=False, basic_mode='known',
                              allow_discards=True, allow_bombs=True)
        player.planner = player.make_planner(board, None)
        for landing in player.resource_landings(board, 100):
            self.assertNotIn(Action.Bomb, landing.moves)
            self.assertNotIn(Action.Discard, landing.moves)

    def test_discards_consume_one_piece_and_leave_the_predictor_aligned(self):
        from board import Action
        predictor = SeedPredictor('discard-sequence-check', 30)
        sequence = predictor.candidates[0].copy()
        for index in range(5):
            predictor.observe(index, sequence[index], sequence[index + 1])
        board = self.make_board(sequence[4], [])
        board.next = Block(sequence[5])
        player = SearchPlayer(use_prediction=False, basic_mode='known', allow_discards=True)
        player.planner = player.make_planner(board, None)
        choices = player.resource_landings(board, 20)
        for landing in choices:
            if Action.Discard in landing.moves:
                self.assertTrue(player.verify_plan(board, landing))
                break
        else:
            self.fail('An available discard was omitted')
        self.assertTrue(board.discard())
        self.assertEqual(board.falling.shape, sequence[5])
        self.assertEqual(board.discards_remaining, 9)
        self.assertTrue(predictor.observe(5, board.falling.shape, sequence[6]))

    def test_verified_seed_predicts_the_authoritative_string_sequence(self):
        seed = 'server-style-563278'
        generator = Random(seed)
        shapes = list(Shape)[:-1]
        expected = []
        for index in range(30):
            expected.append(generator.choice(shapes))
        predictor = SeedPredictor(seed, 30)
        for index in range(5):
            verified = predictor.observe(index, expected[index], expected[index + 1])
            if index < 4:
                self.assertFalse(verified)
        self.assertTrue(verified)
        self.assertEqual(predictor.future(4, 10), expected[4:14])

    def test_integer_and_string_seeds_are_checked_instead_of_assumed(self):
        generator = Random(42)
        shapes = list(Shape)[:-1]
        expected = []
        for index in range(20):
            expected.append(generator.choice(shapes))
        predictor = SeedPredictor('42', 20)
        for index in range(5):
            predictor.observe(index, expected[index], expected[index + 1])
        self.assertEqual(predictor.status, 'verified')
        self.assertEqual(predictor.future(4, 8), expected[4:12])

    def test_prediction_disables_itself_after_a_later_mismatch(self):
        predictor = SeedPredictor('correct-seed', 30)
        sequence = predictor.candidates[0].copy()
        for index in range(5):
            predictor.observe(index, sequence[index], sequence[index + 1])
        self.assertEqual(predictor.status, 'verified')
        wrong = Shape.I
        if wrong is sequence[6]:
            wrong = Shape.O
        self.assertFalse(predictor.observe(5, sequence[5], wrong))
        self.assertEqual(predictor.status, 'mismatch')
        self.assertEqual(predictor.future(5, 10), [])

    def test_prediction_never_includes_the_unplayable_final_preview(self):
        predictor = SeedPredictor('short-game', 10)
        sequence = predictor.candidates[0].copy()
        for index in range(5):
            predictor.observe(index, sequence[index], sequence[index + 1])
        self.assertEqual(predictor.future(8, 6), sequence[8:9])

    def test_missing_seed_uses_visible_piece_search(self):
        board = self.make_board(Shape.T, [])
        player = SearchPlayer(use_prediction=False)
        moves = player.choose_action(board)
        self.assertTrue(moves)
        self.assertEqual(player.predicted_decisions, 0)
        self.assertEqual(player.fallback_decisions, 1)
        self.assertEqual(player.known_decisions, 1)

    def test_environment_seed_enables_prediction_in_a_real_game(self):
        from scripts.benchmark import run_game
        seed = 'environment-roundtrip-852901'
        with patch.dict(os.environ, {'SEED': seed}):
            result = run_game(SearchPlayer, seed, 8, {'block_limit': 8})
        self.assertEqual(result['status'], 'block-limit')
        self.assertEqual(result['prediction_status'], 'verified')
        self.assertEqual(result['predicted_decisions'], 3)
        self.assertEqual(result['planning_failures'], 0)

    def test_whole_game_plan_is_reused_and_checked_in_the_real_engine(self):
        from scripts.benchmark import run_game
        seed = 'full-plan-roundtrip-813726'
        result = run_game(SearchPlayer, seed, 12, {
            'block_limit': 12, 'seed': seed, 'whole_game': True,
            'whole_game_width': 16, 'whole_game_time_limit': 10,
        })
        self.assertEqual(result['status'], 'block-limit')
        self.assertEqual(result['prediction_status'], 'verified')
        self.assertEqual(result['planning_failures'], 0)
        self.assertEqual(result['full_plans'], 1)
        self.assertEqual(result['cached_decisions'], 6)

    def test_a_changed_board_invalidates_the_saved_plan(self):
        from player import Landing
        player = SearchPlayer(seed='changed-full-plan', block_limit=12,
                              whole_game=True, whole_game_width=8,
                              whole_game_time_limit=10)
        sequence = player.predictor.candidates[0].copy()
        for index in range(4):
            player.predictor.observe(index, sequence[index], sequence[index + 1])
        player.turn = 4
        board = self.make_board(sequence[4], [])
        board.next = Block(sequence[5])
        player.saved_plan = [Landing((0,) * 10, 999999, [], 0)]
        moves = player.choose_action(board)
        self.assertTrue(moves)
        self.assertEqual(player.cached_decisions, 0)
        self.assertEqual(player.full_plans, 1)
        self.assertEqual(player.planning_failures, 0)

    def test_wrong_environment_seed_falls_back_for_the_whole_game(self):
        from scripts.benchmark import run_game
        with patch.dict(os.environ, {'SEED': 'not-the-game-seed'}):
            result = run_game(SearchPlayer, 'actual-game-seed', 8, {'block_limit': 8})
        self.assertEqual(result['status'], 'block-limit')
        self.assertEqual(result['prediction_status'], 'mismatch')
        self.assertEqual(result['predicted_decisions'], 0)
        self.assertEqual(result['fallback_decisions'], 7)


if __name__ == '__main__':
    unittest.main()
