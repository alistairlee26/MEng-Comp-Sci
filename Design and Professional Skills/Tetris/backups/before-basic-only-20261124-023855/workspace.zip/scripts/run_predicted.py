import argparse
import os
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import constants
import player


class LiveSearchPlayer(player.SearchPlayer):
    def __init__(self):
        super().__init__(whole_game=False, beam_width=24, prediction_depth=16,
                         setup_rows=12, search_time_limit=0.7)


def main():
    parser = argparse.ArgumentParser(description='Play locally with a matching seed')
    parser.add_argument('--interface', choices=('pygame', 'tkinter', 'terminal'),
                        default='pygame')
    parser.add_argument('--seed', type=int)
    parser.add_argument('--manual', action='store_true')
    parser.add_argument('--live-search', action='store_true',
                        help='Search each turn instead of pausing to plan the whole game')
    args = parser.parse_args()

    seed = constants.DEFAULT_SEED
    if args.seed is not None:
        seed = args.seed
    constants.DEFAULT_SEED = seed
    os.environ['SEED'] = str(seed)
    if args.live_search:
        player.SelectedPlayer = LiveSearchPlayer

    entry_points = {
        'pygame': 'visual-pygame.py',
        'tkinter': 'visual.py',
        'terminal': 'cmdline.py',
    }
    entry = ROOT / entry_points[args.interface]
    sys.argv = [str(entry)]
    if args.manual:
        sys.argv.append('-m')
    os.chdir(str(ROOT))
    runpy.run_path(str(entry), run_name='__main__')


if __name__ == '__main__':
    main()
