import argparse
import hashlib
import json
from pathlib import Path
from secrets import token_hex


ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--games', type=int, default=10)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Choose a new output name; preserve existing frozen protocols')
    basic = json.loads((ROOT / 'configs/basic.json').read_text(encoding='utf-8'))[0]
    predicted = json.loads((ROOT / 'configs/predicted.json').read_text(encoding='utf-8'))[0]
    profiles = [
        {'name': 'basic-v1', 'algorithm': 'baseline-v1', 'prediction': 'missing'},
        basic,
        {'name': 'predicted-v1', 'algorithm': 'baseline-v1', 'prediction': 'environment'},
        predicted,
    ]
    source_names = ('player.py', 'board.py', 'adversary.py', 'constants.py')
    sources = {}
    for name in source_names:
        sources[name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    baseline_sources = {}
    for name in ('player.py', 'planner.py'):
        path = ROOT / 'baselines/v1' / name
        baseline_sources[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    # Parameters and source hashes are collected before generating the holdout.
    seeds = []
    for index in range(args.games):
        seeds.append('comparison-b-' + token_hex(16))
    protocol = {
        'python_version': '3.7.9', 'sources': sources, 'baseline_sources': baseline_sources,
        'profiles': profiles, 'seeds': seeds,
        'comparisons': [
            {'before': 'basic-v1', 'after': basic['name']},
            {'before': 'predicted-v1', 'after': predicted['name']},
        ],
        'rules': [
            'All outcomes count, including early losses and crashes.',
            'No tuning against these seeds; changed parameters require a fresh batch.',
            'Same authoritative string seed for each paired game.',
            'Prediction is conditional on a matching environment SEED.',
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(protocol, indent=2) + '\n', encoding='utf-8')
    stem = args.output.with_suffix('')
    stem.with_name(stem.name + '-profiles.json').write_text(
        json.dumps(profiles, indent=2) + '\n', encoding='utf-8')
    stem.with_name(stem.name + '-seeds.json').write_text(
        json.dumps(seeds, indent=2) + '\n', encoding='utf-8')
    print('Frozen {} paired seeds and {} profiles in {}'.format(
        len(seeds), len(profiles), args.output))


if __name__ == '__main__':
    main()
