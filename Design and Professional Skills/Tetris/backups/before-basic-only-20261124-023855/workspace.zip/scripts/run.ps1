[CmdletBinding()]
param(
    [ValidateSet('pygame', 'tkinter', 'terminal')]
    [string] $Interface = 'pygame',

    [ValidateSet('manual', 'auto')]
    [string] $Mode = 'auto',

    [switch] $Help,

    [switch] $Predict,

    [switch] $LiveSearch,

    [string] $Seed = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$python = Join-Path $projectRoot '.venv\Scripts\python.exe'
$entryPoints = @{
    pygame = 'visual-pygame.py'
    tkinter = 'visual.py'
    terminal = 'cmdline.py'
}
$entryPoint = Join-Path $projectRoot $entryPoints[$Interface]

if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    throw 'Project Python environment missing. Follow the Local setup instructions in README.md.'
}
if (-not (Test-Path -LiteralPath $entryPoint -PathType Leaf)) {
    throw "Game interface missing: $entryPoint"
}

$gameArguments = @()
if ($Predict) {
    $entryPoint = Join-Path $projectRoot 'scripts\run_predicted.py'
    $gameArguments += @('--interface', $Interface)
    if ($Mode -eq 'manual') {
        $gameArguments += '--manual'
    }
    if ($Seed -ne '') {
        $gameArguments += @('--seed', $Seed)
    }
    if ($LiveSearch) {
        $gameArguments += '--live-search'
    }
}
else {
    if ($Mode -eq 'manual') {
        $gameArguments += '-m'
    }
    if ($Seed -ne '') {
        throw 'Use -Predict when supplying a local seed.'
    }
}
if ($Help) {
    $gameArguments += '--help'
}

# The Pygame interface loads its font relative to the current directory.
Push-Location -LiteralPath $projectRoot
try {
    & $python $entryPoint @gameArguments
    $gameExitCode = $LASTEXITCODE
}
finally {
    Pop-Location
}
exit $gameExitCode
